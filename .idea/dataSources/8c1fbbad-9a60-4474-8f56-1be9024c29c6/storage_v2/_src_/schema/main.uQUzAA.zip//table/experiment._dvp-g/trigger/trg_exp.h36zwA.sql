CREATE TRIGGER trg_exp
	after update of
		exp_code,
		exp_name,
		exp_vers,
		exp_desc,
		exp_comm
	on experiment
	begin
		update experiment
		set exp_datu = current_timestamp
		where exp_code = new.exp_code;
	end;

